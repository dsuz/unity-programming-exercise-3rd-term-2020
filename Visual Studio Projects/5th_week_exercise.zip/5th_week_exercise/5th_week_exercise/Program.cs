﻿using System;
using System.Diagnostics;

class Program
{
    static void Main(string[] args)
    {
        Exercise01();
        //Exercise02();
        //Exercise03();

        Console.Write("Hit Enter to exit...");
        Console.ReadLine();
    }

    /// <summary>
    /// 素数を判定する。
    /// </summary>
    static void Exercise01()
    {
        while (true)
        {
            Console.Write("素数かどうか判定します。正の整数を入力して下さい > ");
            string buffer = Console.ReadLine();
            if(buffer.Length == 0)
            {
                break;
            }

            uint number;    // uint は「0 以上の整数」
            
            if (uint.TryParse(buffer, out number))  // out 修飾子は「関数に引数として変数を渡して、変数に値を入れてもらう時」に使う。値をもらう方法としての「戻り値」は一つしか値を返せないために、このように値をもらう手段として引数を使うことがある。参照: 『独習 C#』7.6.6. 出力引数（outキーワード）
            {
                Stopwatch sw = new Stopwatch(); // 実行時間を計るため
                sw.Start();
                bool isPrime = IsPrime(number);
                sw.Stop();

                if (isPrime)
                {
                    Console.WriteLine("{0} は素数です。実行時間: {1}", number, sw.ElapsedTicks.ToString());
                }
                else
                {
                    Console.WriteLine("{0} は素数ではありません。実行時間: {1}", number, sw.ElapsedTicks.ToString());
                }
            }
            else
            {
                Console.WriteLine("入力された値が不正です。");
            }
        }

        Console.WriteLine("終了します。");
    }

    /// <summary>
    /// フィボナッチ数を求める。
    /// </summary>
    static void Exercise02()
    {
        int number = 35;    // いくつのフィボナッチ数を求めるか

        for (uint i = 1; i < number + 1; i++)
        {
            Console.Write(FibonacciNumber(i));
            Console.Write(", ");
        }

        Console.Write("\r\n");
        Console.WriteLine("終了します。");
    }

    /// <summary>
    /// ソートする。
    /// </summary>
    static void Exercise03()
    {
        int[] intArray = { 120, 56423, 12, 93, 2 };
        int[] resultArray = BubbleSort(intArray);

        foreach(var i in resultArray)
        {
            Console.Write(i + ", ");
        }

        Console.Write("\r\n");
        Console.WriteLine("終了します。");
    }

    /// <summary>
    /// パラメーターとして渡された正の整数が素数かどうか判定する。
    /// 素数判定アルゴリズムは「エラトステネスの篩（ふるい）」を使う。
    /// </summary>
    /// <param name="number">判定対象の整数</param>
    /// <returns>素数の場合は true、そうでない場合は false を返す</returns>
    static bool IsPrime(uint number)
    {
        if (number < 2) // 0, 1 は素数ではない
        {
            return false;
        }
        else if (number == 2)   // 2 は素数である
        {
            return true;
        }

        // TODO: 2 から number - 1 までの整数で number を割っていく。割り切れたら number は素数ではないので false を返す。

        // どれでも割り切れなかったら素数である
        return true;
    }

    /// <summary>
    /// number 番目のフィボナッチ数を返す。
    /// </summary>
    /// <param name="number">正の整数</param>
    /// <returns>number 番目のフィボナッチ数</returns>
    static uint FibonacciNumber(uint number)
    {
        if (number == 0)
        {
            Console.WriteLine("与えられた数が不正です。");
        }
        else if (number == 1 || number == 2)
        {
            return 1;
        }

        // TODO: 以下では 0 を返しているが、これを修正して「2つ前のフィボナッチ数」と「1つ前のフィボナッチ数」の和を返すように修正する。
        return 0;
    }

    /// <summary>
    /// 与えられた整数の配列を昇順ソートして返す。
    /// ソートアルゴリズムはバブルソートを使う。
    /// </summary>
    /// <param name="intArray">並び変えたい整数の配列</param>
    /// <returns>昇順ソートした整数の配列</returns>
    static int[] BubbleSort(int[] intArray)
    {
        for (int i = 0; i < intArray.Length; i++)
        {
            for (int j = intArray.Length - 1; i < j; j--)
            {
                if (intArray[j] < intArray[j - 1])
                {
                    // TODO: intArray[j] と intArray[j - 1] を入れ替える
                }
            }
        }

        return intArray;
    }
}
