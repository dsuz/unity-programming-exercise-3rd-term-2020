﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("プログラムを終了するには、Ctrl+C を押してください");

        while (true)
        {
            Console.WriteLine("入力してください");
            Console.Write(">");
            string buf = Console.ReadLine();
            int n;

            if (int.TryParse(buf, out n))
            {
                Exercise01(n);
                //Exercise04(n);
            }
            else
            {
                //Exercise02(buf);
                //Exercise03(buf);
                //Exercise05(buf);
                //Exercise06(buf);
            }
        }
    }

    /// <summary>
    /// あなたは鉛筆を箱買いしました。それぞれの箱には 1 ダースの鉛筆が入っています。
    /// 合計で何ダースの鉛筆を買ったかが入力されるので、買った鉛筆の本数を出力してください。
    /// 1 ダースは 12 本です。
    /// </summary>
    /// <param name="n">購入したダース数</param>
    static void Exercise01(int n)
    {
        Console.WriteLine("");
    }

    /// <summary>
    /// あなたは気温の寒暖差の激しい季節に体調を崩さないように気温の寒暖差が確認するプログラムを作ることにしました。
    /// 最高気温 H 度と最低気温 L 度がスペース区切りで入力されるので寒暖の差が何度かを出力してください。
    /// 例えば
    /// 25 18
    /// と入力された場合
    /// 7
    /// と出力してください。
    /// </summary>
    /// <param name="hl">最高気温と最低気温をスペース区切りで並べた文字列</param>
    static void Exercise02(string hl)
    {
        Console.WriteLine("");
    }

    /// <summary>
    /// あなたはジュースを N ミリリットル手に入れました。
    /// そのジュースを M ミリリットル入るコップにわけることにしました。
    /// N, M の順にスペース区切りで値が与えられるので、いくつのコップにわけることが出来るかを求めてください。
    /// ただし、余ったジュースは自分でこっそり飲んでしまうのでわけた数には含まないことにします。
    /// 例えば以下のような入力であれば
    /// 500 180
    /// 500 ミリリットルのジュースを 180 ミリリットル入るコップにわけるので
    /// 2 つのコップにわけることができ、140 ミリリットルあまるので以下のように出力してください
    /// 2
    /// </summary>
    /// <param name="nm">ジュースの量とコップの容量をスペース区切りで並べた文字列</param>
    static void Exercise03(string nm)
    {
        Console.WriteLine("");
    }

    /// <summary>
    /// あなたの SUICA は、残高が 10,000 円を切っていると自動で 10,000 円をチャージします。
    /// 残高が入力されるので、チャージするべきかどうか判断をし、チャージする場合はチャージ後の残高、必要ない場合はそのままの残高を出力してください。
    /// </summary>
    /// <param name="balance">残高</param>
    static void Exercise04(int balance)
    {
        Console.WriteLine("");
    }

    /// <summary>
    /// N を 2 以上の整数とし、N の約数のうち N 自身を除いたものの和を S とします。 このとき
    /// ・N = S となるような N を完全数
    /// ・|N-S| = 1 となるような N をほぼ完全数
    /// と言うことにしましょう。ここで、|N-S| は N-S の絶対値を意味します。
    /// たとえば、N = 28 のとき、28 の約数は 1, 2, 4, 7, 14, 28 なので、S = 1+2+4+7+14 = 28 となります。従って、28 は完全数です。
    /// また、N = 16 のときには S = 1 + 2 + 4 + 8 = 15 となるので、16 はほぼ完全数です。
    /// 入力された整数が完全数 (perfect) かほぼ完全数 (nearly) かそのいずれでもない (neither) かを判定するプログラムを作成してください。
    /// 
    /// 例１
    /// 入力: 28 16 777
    /// 出力:
    /// perfect
    /// nearly
    /// neither
    /// 
    /// 例２
    /// 入力: 3 4 5 6
    /// 出力:
    /// neither
    /// nearly
    /// neither
    /// perfect
    /// </summary>
    /// <param name="numbers">整数をスペース区切りで並べた文字列</param>
    static void Exercise05(string numbers)
    {

    }

    /// <summary>
    /// Leet と呼ばれるインターネットスラングがあります。
    /// Leet ではいくつかのアルファベットをよく似た形の他の文字に置き換えて表記します。 
    /// Leet の置き換え規則はたくさんありますが、ここでは次の置き換え規則のみを考えましょう。
    /// 
    /// 置き換え前 > 置き換え後
    /// A > 4
    /// E > 3
    /// G > 6
    /// I > 1
    /// O > 0
    /// S > 5
    /// Z > 2
    /// 
    /// 文字列が入力されるので、これを Leet に変換して出力するプログラムを書いてください。
    /// 
    /// 例
    /// ALANTURING > 4L4NTUR1N6
    /// </summary>
    /// <param name="str">文字列</param>
    static void Exercise06(string str)
    {

    }
}
