﻿using System;
using System.Collections.Generic;   // List を使うためにこの行を追加する
using System.Linq;                  // 配列 → List の変換をするためにこの行を追加する
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        //Exercise01();
        Exercise02();
        //Exercise03();
        //Exercise04();
        //Exercise05();
        //Exercise06();
        //Exercise07();
        //Exercise08();
        //Exercise09();
        //Exercise10();
        //Exercise11();

        Console.Write("\r\nHit any key...\r\n");
        Console.ReadKey(true); // 何かキーを押すまで抜けないために書いている
    }

    /// <summary>
    /// 配列の実行s例
    /// </summary>
    static void Exercise01()
    {
        // 配列はごく限られた操作しかできない。例えば、「3番目の要素を取り除く」には以下のような操作をする必要がある。

        int[] intArray1 = { 0, 1, 2, 3, 4, 5 };
        int[] intArray2 = new int[intArray1.Length - 1];

        int counter = 0;
        for (int i = 0; i < intArray1.Length; i++)
        {
            if (i != 2) // 3 番目の要素を取り除く
            {
                intArray2[counter] = intArray1[i];
                counter++;
            }
        }
        
        // 結果を確認する
        foreach (var i in intArray2)
            Console.Write(i.ToString() + " ");

        // このように配列は実践的な操作をするのにたくさん処理を書かなくてはならない。
        // この問題を解決するために List という仕組み（クラス）がある。List の基本的は使い方は Exercise02 を参照せよ。
    }

    /// <summary>
    /// List の基本操作
    /// </summary>
    static void Exercise02()
    {
        // List を初期化する
        List<string> strList = new List<string>();  // List<T> の T に型を指定することで「型 T の List」を表す

        Console.WriteLine("===== Add() で要素を追加する");

        strList.Add("orange");
        strList.Add("apple");
        strList.Add("banana");

        // 配列と同様に扱える
        for (int i = 0; i < strList.Count; i++) // 要素数が Count プロパティである（Length ではない）ことに注意
            Console.WriteLine(strList[i]);

        Console.WriteLine("===== Insert() で途中に要素を追加できる");

        strList.Insert(2, "kiwi");

        foreach (var item in strList)
            Console.WriteLine(item);

        Console.WriteLine("===== ソートができる");
        strList.Sort();

        foreach (var item in strList)
            Console.WriteLine(item);

        Console.WriteLine("===== 要素を削除できる");

        strList.Remove("orange");

        foreach (var item in strList)
            Console.WriteLine(item);

        Console.WriteLine("===== インデックスを指定して途中の要素を削除できる");

        strList.RemoveAt(2);

        foreach (var item in strList)
            Console.WriteLine(item);

        // その他、どんな操作ができるかについては https://itsakura.com/csharp-list や独習 C# 第6章 コレクションの 6.2.1 List（リスト）などを参照せよ。

        Console.WriteLine("===== 配列から List に変換することもできる");

        int[] intArray = { 17, 61, 3, 19, 54, 22 };
        List<int> intList = intArray.ToList();
        intList.Remove(19);

        foreach (var item in intList)
            Console.Write(item.ToString() + " ");
    }

    /// <summary>
    /// 以下のコードをアンコメントして ??? の部分を追記し、以下の結果を出力するコードにせよ。
    /// 結果: 10 30 108 75 が 4 行で出力される
    /// </summary>
    static void Exercise03()
    {
        /*
        var list = new List<???> { 10, 15, 30, 60 };
        list ??? = 75;
        list.??? (15);
        list.??? (2, 108);
        foreach(var ??? in list)
        {
            Console.WriteLine(v);
        }
        */
    }

    /// <summary>
    /// 以下のように、0から10までの乱数を生成してその値を表示し、0が出たら、それまで生成した整数をすべて、奇数・偶数にわけて表示するプログラムを作れ。
    /// この時、入力された奇数・偶数の値は、それぞれ別の、Listで作った可変長配列の中に格納すること。

    /// （実行例）
    /// 
    /// 0～10の値を生成:1
    /// 0～10の値を生成:9
    /// 0～10の値を生成:8
    /// 0～10の値を生成:2
    /// 0～10の値を生成:4
    /// 0～10の値を生成:3
    /// 0～10の値を生成:7
    /// 0～10の値を生成:0                       (← 0が出たら、乱数の生成を終了する)
    /// 
    /// 偶数 : 8 2 4
    /// 奇数 : 1 9 3 7
    /// </summary>
    static void Exercise04()
    {
        Random r = new Random();
        List<int> oddList;  // 奇数のリスト
        List<int> evenList; // 偶数のリスト

        while (true)
        {
            int randomInt = r.Next(0, 10);  // Unity ではなく .NET Framework のみでランダムな整数を得るにはこうする
            Console.WriteLine("0～10の値を出力: {0}", randomInt);
            if (randomInt == 0)
            {
                return;
            }
        }
    }

    /// <summary>
    /// 以下のように、0から10までの乱数を生成しその値を表示し、0が出たら、それまで入力した整数を逆から表示するプログラムを作れ。値はListで作った可変長配列の中に格納すること。

    /// （実行例）
    /// 
    /// 0～10の値を生成:9
    /// 0～10の値を生成:4
    /// 0～10の値を生成:3
    /// 0～10の値を生成:1
    /// 0～10の値を生成:0                       (← 0が出たら、乱数の生成を終了する)
    /// 
    /// 1 3 4 9
    /// </summary>
    static void Exercise05()
    {

    }

    /// <summary>
    /// 以下のように、コンソールから文字列を入力させ続け、何も入力せずEnterを押すと、それまで入力した文字列が「アルファベット順に」全て表示されるプログラムを作れ。このとき文字列は、Listで作った可変長配列に格納すること。
    
    /// （実行例）
    /// 
    /// 文字列を入力:apple
    /// 文字列を入力:good
    /// 文字列を入力:pineapple
    /// 文字列を入力:big
    /// 文字列を入力:dog
    /// 文字列を入力:cowboy
    /// 文字列を入力:                            (← 何も入力せず、Enterを押すと、入力を終了する)
    /// 
    /// apple good pineapple big dog cowboy
    /// </summary>
    static void Exercise06()
    {
        while (true)
        {
            Console.Write("文字列を入力:");
            string buf = Console.ReadLine();
            if (buf.Length == 0)
            {
                return;
            }
        }
    }

    /// <summary>
    /// 前の問題を参考にして、コンソールから文字列を入力させ続けて、何も入力せずEnterを押すと、それまで入力した文字列の中から、5文字以上の単語以外のものがすべて表示されるようにプログラムを作れ。
    /// なお入力され続けていた文字列は、すべて一旦Listに格納し、最後に5文字以上のものを削除してから表示すること。
    /// </summary>
    static void Exercise07()
    {

    }

    /// <summary>
    /// 0から10までの乱数を次々と発生させ、発生した値をListに格納し続け、0が出たら、それまで発生した整数の中から「2」を除いた数を選んで表示するプログラムを作れ。
    /// このとき、発生させた整数値はlistで作った可変長配列の中に格納し、次に 2の入った要素をremove()メソッドで削除してから表示すること。
    /// </summary>
    static void Exercise08()
    {

    }

    /// <summary>
    /// 0から10までの乱数を発生させ、その数値を小さい順に並べて表示されるようなプログラムを作りなさい。0が生成されたら、プログラムは終了するものとする。
    /// なお、それまで入力され続けていた数値は、Listに格納し、適切な場所に挿入すること。
    /// </summary>
    static void Exercise09()
    {
        Random r = new Random();
        List<int> intList = new List<int>();

        while (true)
        {
            int randomInt = r.Next(0, 10);  // Unity ではなく .NET Framework のみでランダムな整数を得るにはこうする
            Console.WriteLine("0～10の値を出力: {0}", randomInt);
            if (randomInt == 0)
            {
                return;
            }
            else
            {
                // ここに randomInt を適切な位置に挿入する処理を書く
            }
        }

        // ここに List の内容を出力する処理を書く
    }

    /// <summary>
    /// int 型のリスト { 5, 4, 3, 1, 5, 5, 5, 6, 5, 2 } を作り、「IndexOf(item, index) 関数を使って」値が 5 である要素の値をすべて -5 に置き換えよ
    /// </summary>
    static void Exercise10()
    {
        
    }

    /// <summary>
    /// int 型のリスト { 0, 5, 4, 3, 1, 5, 5, 5, 6, 5, 2 } を作り、最初の 5 を残して２番目以降の 5 をすべて削除せよ
    /// </summary>
    static void Exercise11()
    {

    }
}
